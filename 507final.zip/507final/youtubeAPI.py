from apiclient.discovery import build
api_key = "AIzaSyBKblmf8f9tD_jk7so8SSvly5S_gS30_ik"
import json
import requests
import codecs
import sys
sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer)
BASE_URL = 'https://www.youtube.com/watch?v='

youtube = build('youtube', 'v3', developerKey = api_key )

def searchYoutube(serachitem):
    res = youtube.search().list(part='snippet', 
                                q = serachitem,
                                type='video',
                                maxResults = 1).execute()
    video_id = res['items'][0]['id']['videoId']
    youtubeUrl = BASE_URL  + video_id
    return youtubeUrl


