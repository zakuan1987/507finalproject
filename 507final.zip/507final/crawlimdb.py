import requests
import json
from bs4 import BeautifulSoup


baseurl = 'https://www.imdb.com/'
catalog_url = baseurl + '/chart/top/?ref_=nv_mv_250'
header = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'}
movie_listings = []


CACHE_FNAME = 'cache.json'

try:
    cache_file = open(CACHE_FNAME, 'r')
    cache_contents = cache_file.read()
    CACHE_DICTION = json.loads(cache_contents)
    cache_file.close()

# if there was no file, no worries. There will be soon!
except:
    CACHE_DICTION = {}

def get_unique_key(url):
  return url

def make_request_using_cache(url, header):
    unique_ident = get_unique_key(url)

    ## first, look in the cache to see if we already have this data
    if unique_ident in CACHE_DICTION:
        print("Getting cached data...")
        return CACHE_DICTION[unique_ident]

    ## if not, fetch the data afresh, add it to the cache,
    ## then write the cache to file
    else:
        print("Making a request for new data...")
        # Make the request and cache the new data
        resp = requests.get(url, headers=header)
        CACHE_DICTION[unique_ident] = resp.text
        dumped_json_cache = json.dumps(CACHE_DICTION)
        fw = open(CACHE_FNAME,"w")
        fw.write(dumped_json_cache)
        fw.close() # Close the open file
        return CACHE_DICTION[unique_ident]



class MovieList:
    def __init__(self, movieHref ,director, actor, movieName ,releaseDate, poster_href):
        self.href = movieHref
        self.dir = director
        self.actor = actor
        self.movieName = movieName
        self.releaseDate = releaseDate
        self.poster = poster_href

    def __str__(self):
        movie_str = 'the movie name is'+ self.movieName + ', directed by'+ self.dir +'. The release date is'+ self.releaseDate + '. The main actor is' + self.actor + '. Genre is' + self.genre
        return movie_str

    def getDetailedInfo(self,details_url):
        next_request = make_request_using_cache(details_url, header)
        detail_soup = BeautifulSoup(next_request, 'html.parser')
        canwrap = detail_soup.find_all(class_='canwrap')
        self.genre = canwrap[2].find('a').text



def scrapeIMDB ():
    page_text = make_request_using_cache(catalog_url, header)
    page_soup = BeautifulSoup(page_text, 'html.parser')
    content_list = page_soup.find(class_= 'lister')
    tbody = content_list.find('tbody')
    table_rows = tbody.find_all('tr')

    for tr in table_rows[0:10]:
        titleColumn = tr.find(class_ = 'titleColumn')
        movieHref =  titleColumn.find('a')['href']
        director = titleColumn.find('a')['title'].split(',')[0]
        actor = titleColumn.find('a')['title'].split(',')[1]
        movieName = titleColumn.find('a').text
        releaseDate = tr.find(class_ = 'secondaryInfo').text

        posterColumn = tr.find(class_ = 'posterColumn')
        poster_href = posterColumn.find('img')['src']

        details_url = baseurl + movieHref

        movie_item = MovieList(movieHref, director, actor , movieName , releaseDate, poster_href)
        movie_item.getDetailedInfo(details_url)
        movie_listings.append(movie_item)

    return movie_listings
